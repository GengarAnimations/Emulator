// Google Drive
var googleProjectId = "hallowed-digit-311307";
var googleApiKey = "AIzaSyDuKbs32MBOZw87EJi0dsPVNHx6D4_QTOQ";
var googleOauthClientId = "478810195063-c83gm38hf14o08gg4oqggql7pp9dqbdl.apps.googleusercontent.com";
// If it asks you, use this scope: https://www.googleapis.com/auth/drive.readonly

// Dropbox
var dropboxAppKey = "2556z2wtdog5rop";

// OneDrive
var onedriveClientId = "31614988-7150-44ca-b17f-d18e3ea1d3af";
